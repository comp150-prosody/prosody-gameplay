package org.rlcommunity.environments.keepAway.finiteStateMachine;

public enum TelegramTypes {
	receivePass
}
