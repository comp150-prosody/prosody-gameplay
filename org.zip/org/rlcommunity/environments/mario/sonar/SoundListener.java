package org.rlcommunity.environments.mario.sonar;

public interface SoundListener extends SoundSource
{
}